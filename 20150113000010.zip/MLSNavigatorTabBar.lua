waxClass{"MLSNavigatorTabBar",UIView}
function tabButtonPressed(self,sender)
	self:ORIGtabButtonPressed(sender)
	local alert = UIAlertView:initWithTitle_message_delegate_cancelButtonTitle_otherButtonTitles("这是个标题","哈哈，白神你好！！",nil,"取消","确定",nil)
	alert:show()
end

