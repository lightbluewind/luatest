require "wax.luaspec.luaspec"
require "wax.luaspec.luamock"
