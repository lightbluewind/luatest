require "wax.ext.table"
require "wax.ext.string"
require "wax.ext.number"
require "wax.ext.http"
