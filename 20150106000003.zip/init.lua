setmetatable(_G, {
  __index = function(self, key)
    local class = wax.class[key]
    if class then self[key] = class end -- cache it for future use

    if not class and key:match("^[A-Z][A-Z][A-Z][^A-Z]") then -- looks like they were trying to use an objective-c obj
      print("WARNING: No object named '" .. key .. "' found.")
    end

    return class
  end
})
local t=package.preload;
t['wax.enums']=function()end;
t['wax.ext.http']=function()end;
t['wax.ext']=function()end;
t['wax.ext.number']=function()end;
t['wax.ext.string']=function()end;
t['wax.ext.table']=function()end;
t['wax.helpers.WaxServer']=function()end;
t['wax.helpers.autoload']=function()end;
t['wax.helpers.base64']=function()end;
t['wax.helpers.bit']=function()end;
t['wax.helpers.cache']=function()end;
t['wax.helpers.callback']=function()end;
t['wax.helpers.frame']=function()end;
t['wax.helpers']=function()end;
t['wax.helpers.pickView']=function()end;
t['wax.helpers.time']=function()end;
t['wax.init']=function()end;
t['wax.luaspec']=function()end;
t['wax.luaspec.luamock']=function()end;
t['wax.luaspec.luaspec']=function()end;
t['wax.repl']=function()end;
t['wax.structs']=function()end;
t['wax.waxClass']=function()end;
t='////////';
(function()end)();

require "wax.ext"
require "wax.enums"
require "wax.structs"
require "wax.waxClass"
require "wax.helpers"