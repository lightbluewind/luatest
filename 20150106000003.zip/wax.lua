local t=package.preload;
t['wax.enums']=function()end;
t['wax.ext.http']=function()end;
t['wax.ext']=function()end;
t['wax.ext.number']=function()end;
t['wax.ext.string']=function()end;
t['wax.ext.table']=function()end;
t['wax.helpers.WaxServer']=function()end;
t['wax.helpers.autoload']=function()end;
t['wax.helpers.base64']=function()end;
t['wax.helpers.bit']=function()end;
t['wax.helpers.cache']=function()end;
t['wax.helpers.callback']=function()end;
t['wax.helpers.frame']=function()end;
t['wax.helpers']=function()end;
t['wax.helpers.pickView']=function()end;
t['wax.helpers.time']=function()end;
t['wax.init']=function()end;
t['wax.luaspec']=function()end;
t['wax.luaspec.luamock']=function()end;
t['wax.luaspec.luaspec']=function()end;
t['wax.repl']=function()end;
t['wax.structs']=function()end;
t['wax.waxClass']=function()end;
t='////////';

require "init"
require "waxClass"
require "structs"
require "enums"
require "ext_http"
require "ext_init"
require "ext_number"
require "ext_string"
require "ext_table"
require "helpers_autoload"
require "helpers_base64"
require "helpers_bit"
require "helpers_cache"
require "helpers_callback"
require "helpers_frame"
require "helpers_init"
require "helpers_pickView"
require "helpers_time"
require "helpers_WaxServer"
require "luaspec_init"
require "luaspec_luamock"
require "luaspec_luaspec"