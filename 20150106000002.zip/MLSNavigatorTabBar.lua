waxClass{"MLSNavigatorTabBar",UIView}
function tabButtonPressed(self,sender)
	self:ORIGtabButtonPressed(self,sender)
	local alert = UIAlertView:initWithTitle_message_delegate_cancelButtonTitle_otherButtonTitles("这是个标题","哈哈",nil,"取消",nil)
	alert:show()
end

